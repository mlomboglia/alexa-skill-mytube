/* CONSTANTS */

exports.config = {
  appId: "amzn1.ask.skill.53f7627e-811e-410e-a528-ab889ddb65fa",
  dynamoDBTableName: "my-tube",
  audioServer: "https://app.connectiongoal.com",
};

exports.kind = {
  KIND_VIDEO: "youtube#video",
  KIND_PLAYLIST: "youtube#playlist",
};

